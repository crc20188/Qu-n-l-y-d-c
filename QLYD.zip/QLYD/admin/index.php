<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản trị viên</title>
</head>
<body>
    <h1> đây là trang quản trị viên</h1>
</body>
</html>