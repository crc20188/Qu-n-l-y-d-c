<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "quanlysanxuatyduoc";

// Tạo kết nối
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối lỗi: " . $conn->connect_error);
}

//echo "Kết nối thành công";

// Thực hiện các truy vấn MySQL ở đây...

// Đóng kết nối
// $conn->close();
?>

