//<?php
//session_start();
//include './connection/connection.php'; // Include file kết nối

//if ($_SERVER["REQUEST_METHOD"] === "POST") {
   // $TaiKhoan = $_POST["username"];
   // $Matkhau = $_POST["password"];

    // Sử dụng câu lệnh SQL để kiểm tra tài khoản và mật khẩu
   // $sql = "SELECT * FROM Login WHERE username = '$TaiKhoan' AND password = '$Matkhau'";
  //  $result = $conn->query($sql);

   // if ($result->num_rows > 0) {
        // Đăng nhập thành công
   //     $_SESSION["username"] = $TaiKhoan;
  ///      header("Location: dashboard.php");
  //      exit();
  //  } else {
        // Đăng nhập thất bại
       // $error_message = "Tên đăng nhập hoặc mật khẩu không đúng.";
 //   }
//}

// Đóng kết nối cơ sở dữ liệu
//$conn->close();
//?>
<!DOCTYPE html> 
<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<link rel="stylesheet" href="style.css"/> 
</head> 
<body> 
<form action='login.php' class="dangnhap" method='POST'> 
Tên đăng nhập : <input type='text' name='username' /> 
Mật khẩu : <input type='password' name='password' /> 
<input type='submit' class="button" name="dangnhap" value='Đăng nhập' /> 
<?php require 'xuly.php';?> 
<form> 
</body> 
</html>