<?php
include "../admin/connection/connection.php";

$result=mysqli_query($conn,"SELECT * FROM login");
var_dump(mysqli_fetch_all($result));
?>