<?php
    require_once("../admin/connection/connection.php");
    include("../pages/header.php");
    $id=$_GET["id"];
    $sql="SELECT * FROM sanpham where MaSanPham=$id";
    $resul=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($resul);
?>
<style>
    form {
  max-width: 600px;
  margin: 50px auto;
  padding: 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    }

    input {
    width: 100%;
    padding: 10px;
    margin-bottom: 16px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
    }

    button {
    background: #1d1f24;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    }

    button:hover {
    background: #141517;
    }
    .select-container {
  position: relative;
  display: inline-block;
    }

    .select-container select {
    width: 100%;
    padding: 10px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
    }

    .select-container::before {
    content: '\25BC';
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    pointer-events: none;
    }

</style>
<form method="post" action="update.php">
<label for="productName">Mã sản phẩm:</label>
    <input type="text" id="productName" name="MaSanPham" required value="<?php echo $row['MaSanPham'] ?>">

    <label for="productName">Tên sản phẩm:</label>
    <input type="text" id="productName" name="TenSanPham" required value="<?php echo $row['TenSanPham'] ?>">

    <label for="date">Ngày:</label>
    <input type="date" id="date" name="Ngay" required value="<?php echo $row['Ngay'] ?>">

    <label for="caoLong">Cao Lõng:</label>
    <input type="text" id="caoLong" name="CaoLong" required value="<?php echo $row['CaoLong'] ?>">

    <label for="taDuoc">Tá Dược:</label>
    <input type="text" id="taDuoc" name="TaDuoc" required value="<?php echo $row['TaDuoc'] ?>">

    <label for="nguoiKiemSoat">Người kiểm soát:</label>
    <input type="text" id="nguoiKiemSoat" name="NguoiKiemSoat" required value="<?php echo $row['NguoiKiemSoat'] ?>">

    <label for="nguoiPhaChe">Người pha chế:</label>
    <input type="text" id="nguoiPhaChe" name="NguoiPhaChe" required value="<?php echo $row['NguoiPhaChe'] ?>">

    <label for="startTime">Giờ bắt đầu:</label>
    <input type="time" id="startTime" name="GioBatDau" required value="<?php echo $row['GioBatDau'] ?>">

    <label for="endTime">Giờ kết thúc:</label>
    <input type="time" id="endTime" name="GioKetThuc" required value="<?php echo $row['GioKetThuc'] ?>">

    <label for="temperature">Nhiệt độ:</label>
    <input type="text" id="temperature" name="NhietDo" required value="<?php echo $row['NhietDo'] ?>">

    <label for="humidity">Độ ẩm:</label>
    <input type="text" id="humidity" name="DoAm" required value="<?php echo $row['DoAm'] ?>">

    <label for="soLo">Số lô:</label>
    <div class="select-container">
    <select id="SoLo" name="SoLo" required value="<?php echo $row['SoLo'] ?>">
    <?php
    $sql = "SELECT SoLo FROM solo";
    $qr = mysqli_query($conn, $sql);

    while ($rows = mysqli_fetch_array($qr)) {
        $sl = $rows["SoLo"];
        echo "<option value='$sl'>$sl</option>";
    }
    ?>
</select>

    </div>
</br></br>
    <button type="submit" value="Submit">Sửa</button>
    <button style="text-align:center;"><a href="./index.php">Xem quy trình</a></button>
</form>



