<?php
    $msp=$_POST['MaSanPham'];
    $Ten=$_POST['TenSanPham'];
    $Ngay=$_POST['Ngay'];
    $CaoLong=$_POST['CaoLong'];
    $TaDuoc=$_POST['TaDuoc'];
    $NguoiKiemSoat=$_POST['NguoiKiemSoat'];
    $nqc=$_POST['NguoiPhaChe'];
    $gbd=$_POST['GioBatDau'];
    $gkt=$_POST['GioKetThuc'];
    $nd=$_POST['NhietDo'];
    $da=$_POST['DoAm'];
    $sl=$_POST['SoLo'];

    
    require_once '../admin/connection/connection.php';

    $sql = "INSERT INTO sanpham (MaSanPham,TenSanPham,Ngay,CaoLong,TaDuoc,NguoiKiemSoat,NguoiPhaChe,GioBatDau,GioKetThuc,NhietDo,DoAm,SoLo) 
    VALUES('$msp','$Ten','$Ngay','$CaoLong','$TaDuoc','$NguoiKiemSoat','$nqc','$gbd','$gkt','$nd','$da','$sl')";
    if (mysqli_query($conn, $sql)) {
        header("Location: index.php");
    } else {
        echo "Lỗi: " . mysqli_error($conn);
    }
?>