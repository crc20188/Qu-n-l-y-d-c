<?php
    //lấy dữ liệu id xoá
    $qtid=$_GET['id'];
    require_once '../admin/connection/connection.php';

    $sql="DELETE FROM sanpham where MaSanPham=$qtid";

    mysqli_query($conn,$sql);
    header("Location: index.php");

?>