<?php
include("../admin/connection/connection.php");
 ?>
 <style>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
body {
  font-family: "Segoe UI", sans-serif;
  color: #333;
  background-image:url(../img/background.png);
    background-repeat: no-repeat;
    background-size:cover;
/*   background: #cecece; */
}
#section{
    /* background-color: white; */
    width: 100%;
    height: auto;
}
.header{
    width: auto;
    height: auto;
    display: flex;
  justify-content: space-between;
}
.logo img{
    float: left;
    width: 10%;
    height: 11%;
    margin:1px 0px -3px 5px;
}
.dropdown {
  max-width: 13em;
  margin: 30px auto 0;
  position: relative;
  width: 100%;
}

.dropdown-btn {
  background: #1d1f24;
  font-size: 18px;
  width: 100%;
  border: none;
  color: #fff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.7em 0.5em;
  border-radius: 0.5em;
  cursor: pointer;
}

.arrow {
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-top: 6px solid #fff;
  transition: transform ease-in-out 0.3s;
}

.dropdown-content {
  list-style: none;
  position: absolute;
  top: 3.2em;
  width: 100%;
  visibility: hidden;
  overflow: hidden;
}

.dropdown-content li {
  background: #2f3238;
  border-radius: 0.5em;
  position: relative;
  left: 100%;
  transition: 0.5s;
  transition-delay: calc(60ms * var(--delay));
}

.dropdown-btn:focus + .dropdown-content li {
  left: 0;
}

.dropdown-btn:focus + .dropdown-content {
  visibility: visible;
}

.dropdown-btn:focus > .arrow {
  transform: rotate(180deg);
}

.dropdown-content li:hover {
  background: #1d1f24;
}

.dropdown-content li a {
  display: block;
  padding: 0.7em 0.5em;
  color: #fff;
  margin: 0.1em 0;
  text-decoration: none;
}
 </style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>QUẢN LÝ Y DƯỢC</title>
</head>
<body>
    <div id="header">
        Chào mừng bạn đến với web quản lý y dược
    </div>
    
    <div id="section">
        <div class="header"></div>
        <div class="logo">
            <img src="../img/LOGO-DHYD.png" alt="Logo Trường đại học y dược">
        </div>
    </div>

    <div class="dropdown">
  <button class="dropdown-btn" aria-haspopup="menu">
    <span id="dropdown-text">Chức năng</span>
    <span class="arrow"></span>
</button>
  <ul class="dropdown-content" role="menu">
  <li style="--delay: 1;"><a href="../pages/index.php" onclick="changeText('Trang chủ')"> Trang chủ</a></li>
    <li style="--delay: 2;"><a href="../sanpham/index.php" onclick="changeText('Quản lý sản phẩm')"> Quản lý sản phẩm</a></li>
    <li style="--delay: 3;"><a href="../me/index.php" onclick="changeText('Quản lý số mẻ')"> Quản lý số mẻ</a></li>
    <li style="--delay: 4;"><a href="../solo/index.php" onclick="changeText('Số lô')"> Số lô</a></li>
</ul>


</div>
