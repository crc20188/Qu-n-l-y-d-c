<div id="footer"></div>
<script>
   function changeText(newText) {
    document.getElementById('dropdown-text').innerText = newText;
    }
</script>
</body>
</html>