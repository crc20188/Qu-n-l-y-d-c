<?php
$SoLo=$_POST['sl'];
$NgayThang=$_POST['nt'];
$NguoiKiemSoat=$_POST['nks'];
$NguoiPhaChe=$_POST['npc'];
require_once("../admin/connection/connection.php");

$sql="INSERT INTO solo(SoLo,NgayThang,NguoiKiemSoat,NguoiPhaChe) VALUES('$SoLo','$NgayThang','$NguoiKiemSoat','$NguoiPhaChe')";

if(mysqli_query($conn,$sl)){
header("Location:index.php");
}
?>