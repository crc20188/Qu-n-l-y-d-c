<?php 
$id=$_GET['id'];
require_once("../admin/connection/connection.php");

$sql="DELETE FROM solo where SoLo=$id";
if(mysqli_query($conn,$sql)){
    header("location: index.php");
}
?>