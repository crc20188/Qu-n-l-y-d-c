<?php 
$id=$_GET["id"];

require_once("../admin/connection/connection.php");

$sql="SELECT * FROM solo where SoLo=$id";
$resul=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($resul);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style_quytrinh.css">
    <title>Cập nhật số lô</title>
</head>
<body>
<form action="update.php" method="post">
    <label for="ngayThang">Ngày Tháng:</label>
    <input type="date" id="ngayThang" name="ngayThang" required value="<?php echo $row["NgayThang"] ?>">
</select>
</input>
<button type="submit" value="Submit">Cập nhật</button>

</form>
</body>
</html>