<?php
include("../pages/header.php");
?>

<style>
    
        .cum_table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    .cum_table th, .cum_table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    .cum_table th {
        background-color: #4CAF50; /* Màu nền xanh */
        color: white; /* Màu chữ trắng */
        text-align: center;
    }

    .cum_table tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    .cum_table tr:hover {
        background-color: #ddd;
    }
    .cum_table tr td{
        text-align: center;
    }
    .action-column {
            display: flex;
            justify-content: space-around;
            align-items: center;
        }

        .action-column button {
            padding: 6px 12px;
            cursor: pointer;
        }

        .delete-button {
            background-color: #e74c3c;
            color: white;
            border: none;
        }

        .edit-button {
            background-color: #3498db;
            color: white;
            border: none;
        }

        .add-button {
            background-color: #2ecc71;
            color: white;
            border: none;
        }
</style>
<button class="add-button"><a href="./ithem.php">Thêm</a></button></br>
<table class="cum_table">
    <tr>
        <th>Số lô</th>
        <th>Ngày tháng</th>
        <th>Người kiểm soát</th>
        <th>Người pha chế</th>
        <th>Chức năng</th>
    </tr>
    <?php
    $sql="select * from solo";
    $qr=mysqli_query($conn,$sql);
    while($rows=mysqli_fetch_array($qr)){
    ?>
   <tr>
    <td><?php echo $rows["SoLo"] ?></td>
    <td><?php echo $rows["NgayThang"] ?></td>
    <td><?php echo $rows['NguoiKiemSoat'] ?></td>
    <td><?php echo $rows['NguoiPhaChe'] ?></td>
   <td class="action-column">
        <button class="delete-button"><a onclick="return confirm('Bạn có thật sự muốn xoá');" href="x?id=<?php echo $rows["SoLo"]?>">Xoá</a></button>
        <button class="edit-button"><a href="edit.php?id=<?php echo $rows['SoLo']?>">Sửa</a></button>
    </td>
   </tr>
   <?php }?>
</table>

