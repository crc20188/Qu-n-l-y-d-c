<?php 
  $msp=$_POST['SoLo'];
  $Ten=$_POST['NgayThang'];
  $Ngay=$_POST['NguoiKiemSoat'];
  $CaoLong=$_POST['NguoiPhaChe'];
  
  require_once '../admin/connection/connection.php';

  $sql = "INSERT INTO solo (SoLo,NgayThang,NguoiKiemSoat,NguoiPhaChe) 
  VALUES('$SoLo','$NgayThang','$NguoiKiemSoat','$NguoiPhaChe')";
  if (mysqli_query($conn, $sql)) {
      header("Location: index.php");
  } else {
      echo "Lỗi: " . mysqli_error($conn);
  }
?>