<?php 
    include("../pages/header.php");
?>
<style>
    form {
  max-width: 600px;
  margin: 50px auto;
  padding: 20px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    }

    input {
    width: 100%;
    padding: 10px;
    margin-bottom: 16px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
    }

    button {
    background: #1d1f24;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    }

    button:hover {
    background: #141517;
    }
    .select-container {
  position: relative;
  display: inline-block;
    }

    .select-container select {
    width: 100%;
    padding: 10px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
    }

    .select-container::before {
    content: '\25BC';
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    pointer-events: none;
    }

</style>
<form method="post" action="them.php">
    <label for="productName">Số lô</label>
    <input type="text" id="productName" name="sl" required>

    <label for="date">Ngày tháng:</label>
    <input type="date" id="date" name="nt" required>

    <label for="caoLong">Người kiểm soát</label>
    <input type="text" id="caoLong" name="nks" required>

    <label for="taDuoc">Người pha chế</label>
    <input type="text" id="taDuoc" name="npc" required>

    <button type="submit" value="Submit">Thêm</button>
    <button style="text-align:center;"><a href="./index.php">Xem quy trình</a></button>
</form>
