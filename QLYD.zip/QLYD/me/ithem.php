<?php include("../admin/connection/connection.php");
include("../pages/header.php");
?>


<style>
        form {
            margin-top: 10px;
            margin-left: 33%;
            margin-right: 30%;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 500px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #333;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 4px;
            transition: 0.3s;
        }

        input:focus {
            border-color: #4caf50;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }
</style>
<form action="./them.php" method="post">
        <label for="soMe">Số Mẽ:</label>
        <input type="text" id="soMe" name="soMe" required>

        <label for="ngayGioNhap">Ngày Giờ Nhập:</label>
        <input type="datetime-local" id="ngayGioNhap" name="ngayGioNhap" required>

        <label for="soLo">Số lô:</label>
        <select id="SoLo" name="SoLo" required>
    <?php
    $sql = "SELECT SoLo FROM solo";
    $qr = mysqli_query($conn, $sql);

    while ($rows = mysqli_fetch_array($qr)) {
        $sl = $rows["SoLo"];
        echo "<option value='$sl'>$sl</option>";
    }
    ?>
    </select>

        <label for="caoLyThuyet">Cao lõng lý thuyết:</label>
        <input type="text" id="caoLyThuyet" name="CaoLongLyThuyet" required>

        <label for="taDuocLyThuyet">Tá dược lý thuyết:</label>
        <input type="text" id="taDuocLyThuyet" name="TaDuocLyThuyet" required>

        <label for="caoKhoThucTe">Cao khô thực tế:</label>
        <input type="text" id="caoKhoThucTe" name="CaoKhoThucTe" required>

        <label for="nguoiKiemSoat">Người kiểm soát:</label>
        <input type="text" id="nguoiKiemSoat" name="NguoiKiemSoat" required>

        <label for="nguoiPhaChe">Người pha chế:</label>
        <input type="text" id="nguoiPhaChe" name="NguoiPhaChe" required>

        <label for="gioBatDau">Giờ bắt đầu:</label>
        <input type="time" id="gioBatDau" name="GioBatDau" required>

        <label for="gioKetThuc">Giờ kết thúc:</label>
        <input type="time" id="gioKetThuc" name="GioKetThuc" required>

        <label for="nhietDo">Nhiệt độ:</label>
        <input type="text" id="nhietDo" name="NhietDo" required>

        <label for="doAm">Độ ẩm:</label>
        <input type="text" id="doAm" name="DoAm" required>

        <label for="maSanPham">Mã sản phẩm:</label>
        <select id="maSanPham" name="MaSanPham" required>
    <?php
    $sql = "SELECT MaSanPham FROM sanpham";
    $qr = mysqli_query($conn, $sql);

    while ($rows = mysqli_fetch_array($qr)) {
        $sl = $rows["MaSanPham"];
        echo "<option value='$sl'>$sl</option>";
    }
    ?>
    </select>

        <!-- Add more labels and input fields as needed -->
<button type="submit" value="Submit">Thêm</button>
</form>



