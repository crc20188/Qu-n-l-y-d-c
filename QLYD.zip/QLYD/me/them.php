<?php
$sm=$_POST['soMe'];
$ngay=$_POST['ngayGioNhap'];
$sl=$_POST['SoLo'];
$cllt=$_POST['CaoLongLyThuyet'];
$tdlt=$_POST['TaDuocLyThuyet'];
$cktt=$_POST['CaoKhoThucTe'];
$nks=$_POST['NguoiKiemSoat'];
$npc=$_POST['NguoiPhaChe'];
$gbd=$_POST['GioBatDau'];
$gkt=$_POST['GioKetThuc'];
$nd=$_POST['NhietDo'];
$da=$_POST['DoAm'];
$sp=$_POST['MaSanPham'];

 require_once("../admin/connection/connection.php");

 $sql = "INSERT INTO me (SoMe,NgayGio,SoLo,CaoLongLyThuyet,TaDuocLyThuyet,CaoKhoThucTe,NguoiKiemSoat,NguoiPhaChe,GioBatDau,GioKetThuc,NhietDo,DoAm,MaSanPham) 
 VALUES ('$sm','$ngay','$sl','$cllt','$tdlt','$cktt','$nks','$npc','$gbd','$gkt','$nd','$da','$sp')";

if (mysqli_query($conn, $sql)) {
    header("Location: index.php");
} else {
    echo "Lỗi: " . mysqli_error($conn);
}
?>

