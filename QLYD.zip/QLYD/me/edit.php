<?php 
$id=$_GET["id"];

require_once("../admin/connection/connection.php");

$sql="SELECT * FROM me where IdMe=$id";
$resul=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($resul);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style_quytrinh.css">
    <title>Cập nhật mẽ</title>
</head>
<body>
<form action="update.php" method="post">
    <label for="ngayThang">Ngày Tháng:</label>
    <input type="datetime" id="ngayThang" name="NgayGioNhap" required value="<?php echo $row["NgayGioNhap"] ?>">
    <select id="chonID" name="IdQuyTrinh" required>
    <?php
    $sql = "SELECT IdQuyTrinh FROM quytrinh";
    $qr = mysqli_query($conn, $sql);

    while ($rows = mysqli_fetch_array($qr)) {
        $idQuyTrinh = $rows["IdQuyTrinh"];
        echo "<option value='$idQuyTrinh'>$idQuyTrinh</option>";
    }
    ?>
</select>
</input>
<button type="submit" value="Submit">Cập nhật</button>

</form>
</body>
</html>