<?php 
$NgayGioNhap=$_POST['NgayGioNhap'];
$IdQuyTrinh=$_POST['IdQuyTrinh'];

require_once("../admin/connection/connection.php");
$sql="INSERT INTO me (NgayGioNhap,IdQuyTrinh) values('$NgayGioNhap','$IdQuyTrinh') ";

if(mysqli_query($conn,$sql)){
    header("location: index.php");
}

?>